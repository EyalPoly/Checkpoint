package com.checkpoint.models;

public class City {
    public String name;
    public int rank;
}
