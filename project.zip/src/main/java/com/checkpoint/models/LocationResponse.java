package com.checkpoint.models;

public class LocationResponse {
    private Location[] locations;

    public Location[] getLocations() {
        return locations;
    }
}
