package com.checkpoint.services;

import com.checkpoint.models.CityListResponse;
import com.checkpoint.models.Location;
import com.checkpoint.models.WeatherResponse;
import com.google.gson.Gson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.stream.Collectors;

public class WeatherAutomation {
    private static final Logger logger = LoggerFactory.getLogger(WeatherAutomation.class);
    private static final String CITY_LIST_URL = "http://weather-automation-checkpoint-task.westeurope.cloudapp.azure.com:3000/cities";
    private static final String Location_API_URL = "http://api.openweathermap.org/geo/1.0/direct?q=%s&limit=1&appid=5abc828db62c2d79d0fd9f96e98059c6";
    private static final String WEATHER_API_URL = "http://api.openweathermap.org/data/2.5/weather?lat=%s&lon=%s&appid=5abc828db62c2d79d0fd9f96e98059c6&units=metric";
    private static final HttpClient httpClient = HttpClient.newHttpClient();
    private static final Gson gson = new Gson();

    public static void main(String[] args) {
        List<String> cities = fetchCityList();
        logger.info("Fetched {} cities: {}", cities.size(), cities);

        List<CompletableFuture<Void>> futures = new ArrayList<>();
        List<String> results = new CopyOnWriteArrayList<>(); // Thread-safe list

        for (String city : cities) {
            futures.add(CompletableFuture.runAsync(() -> {
                Location locationResult = fetchLocation(formatCityName(city));
                if (locationResult != null) {
                    String result = fetchWeather(locationResult, city);
                    if (result != null) {
                        results.add(result);
                    }
                }
            }));
        }

        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
        results.forEach(System.out::println);
    }

    private static List<String> fetchCityList() {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(CITY_LIST_URL))
                .build();

        try {
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            logger.info("Fetched city list successfully. Response body: {}", response.body());

            CityListResponse cityListResponse = gson.fromJson(response.body(), CityListResponse.class);
            return cityListResponse.cities.stream()
                    .map(city -> city.name)
                    .collect(Collectors.toList());

        } catch (IOException | InterruptedException | RuntimeException e) {
            logger.error("Error occurred while fetching or parsing the city list.", e);
        }

        return Collections.emptyList();
    }

    private static <T> T fetchData(String url, Function<String, T> parser, String city) {
        int retries = 0;
        int max_retries = 3;

        while (retries < max_retries) {
            try {
                TimeUnit.MILLISECONDS.sleep((long) (Math.random() * 1000));  // Random delay to avoid rate limits

                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(url))
                        .build();

                HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
                if (response.statusCode() == 200) {
                    logger.info("Fetched body: {}", response.body());
                    return parser.apply(response.body());

                } else if (response.statusCode() == 429) {
                    logger.warn("Rate limit exceeded for API. Retrying... [{}]", city);
                    retries++;
                    TimeUnit.SECONDS.sleep(2);
                } else {
                    logger.error("Failed to retrieve data for {}. HTTP Status: {}", city, response.statusCode());
                    return null;
                }
            } catch (IOException | InterruptedException e) {
                logger.error("Error fetching data for {}. Retrying...", city, e);
                retries++;
            }
        }

        logger.error("Failed to fetch data for {} after {} retries", city, max_retries);
        return null;
    }

    public static Location fetchLocation(String city) {
        if (city == null) return null;
        String url = String.format(Location_API_URL, city);

        return fetchData(url, responseBody -> parseLocation(responseBody, city), city);
    }

    private static String fetchWeather(Location location, String city) {
        String url = String.format(WEATHER_API_URL, location.getLat(), location.getLon());

        return fetchData(url, responseBody -> parseWeather(responseBody, city), city);
    }

    private static String parseWeather(String responseBody, String city) {
        try {
            WeatherResponse weatherResponse = gson.fromJson(responseBody, WeatherResponse.class);
            double temperature = weatherResponse.getMain().getTemp();
            String result = String.format("%s: %.2f°C", city, temperature);
            logger.info("Got city weather: {}", result);
            return result;

        } catch (Exception e) {
            logger.error("Failed to parse weather data for {}", city, e);
            return null;
        }
    }

    private static Location parseLocation(String responseBody, String city) {
        try {
            Type locationListType = new TypeToken<List<Location>>(){}.getType();

            List<Location> locations = gson.fromJson(responseBody, locationListType);

            if (locations != null && !locations.isEmpty()) {
                Location location = locations.get(0);

                double latitude = location.getLat();
                double longitude = location.getLon();

                logger.info("Location data found for {}: {}, {}", city, latitude, longitude);
                return location;
            } else {
                logger.warn("No location data found for {}", city);
                return null;
            }
        } catch (Exception e) {
            logger.error("Failed to parse location data for {}", city,  e);
            return null;
        }
    }

    private static String formatCityName(String city) {
        if (city == null || city.trim().isEmpty()) {
            logger.error("Empty city name: {} - Skipping", city);
            return null;
        }

        // Replace spaces with hyphens
        return city.trim().replace(" ", "-");
    }
}