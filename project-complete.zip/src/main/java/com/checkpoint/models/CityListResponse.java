package com.checkpoint.models;

import java.util.List;

public class CityListResponse {
    public List<City> cities;
}
