package com.checkpoint.models;

public class WeatherResponse {
    private Main main;

    public static class Main {
        private double temp;

        public double getTemp() {
            return temp;
        }
    }

    public Main getMain() {
        return main;
    }
}

